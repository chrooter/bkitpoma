package com.bkitmobile.poma.facebook.client;

import com.google.gwt.core.client.EntryPoint;

public class FaceBook implements EntryPoint {
	@Override
	public void onModuleLoad() {
		// TODO Auto-generated method stub

	}
}
