package com.bkitmobile.poma.facebook.server;

public class FacebookResponse {

}
