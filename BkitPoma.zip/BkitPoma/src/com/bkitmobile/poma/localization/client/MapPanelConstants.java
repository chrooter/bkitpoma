package com.bkitmobile.poma.localization.client;

public interface MapPanelConstants extends com.google.gwt.i18n.client.Constants {
	String terrainLabel();

	String hybridLabel();

	String trafficLabel();

	String earthLabel();

	String mapTypeLabel();
	
	String traceAllLabel();
}