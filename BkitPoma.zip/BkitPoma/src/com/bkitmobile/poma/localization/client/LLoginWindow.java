package com.bkitmobile.poma.localization.client;

public interface LLoginWindow extends com.google.gwt.i18n.client.Constants {
    String usernameFill();
    String checkEmail();
    String txtPassword_setEmptyText();
    String btnLogin();
    String msgbox_title_incor();
    String txtUsername_setEmptyText();
    String openIdLogin();
    String sendMailFail();
    String msgbox_text_user_invalid();
    String msgbox_text_pass_invalid();
    String btnForgotPass();
    String window_title();
    String msgbox_title_err();
    String pomaPass();
    String lbl1stURL_username();
    String sendMailSuccess();
    String pomaLoginMessage();
    String lblPassword();
    String btnRegister();
    String btnSubmit_text();
    String msgbox_text_userpass_invalid();
    String pomaLogin();
    String pomaUsername();
	String msgbox_text_cannotlogin();
};