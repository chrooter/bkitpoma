package com.bkitmobile.poma.localization.client;

public interface WayPointTablePanelConstants extends com.google.gwt.i18n.client.Constants {
    String time();
    String panelTitleNormal();
    String panelTitleWithTrackID();
}