package com.bkitmobile.poma.localization.client;

public interface Message extends com.google.gwt.i18n.client.Messages {

}
