package com.bkitmobile.poma.localization.client;

public interface WayPointOverlayConstants extends com.google.gwt.i18n.client.Constants {
    String address();
    String speed();
    String longitude();
    String latitude();
}