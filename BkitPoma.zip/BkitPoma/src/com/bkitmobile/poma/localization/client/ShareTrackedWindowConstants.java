package com.bkitmobile.poma.localization.client;

public interface ShareTrackedWindowConstants extends com.google.gwt.i18n.client.Constants {
    String msb_insertStaff_trackernotexist();
    String msb_removemanage();
    String btnInsertStaff();
    String ccManage();
    String btnReset();
    String btnRemoveManage();
    String btnRemoveStaff();
    String msb_insertManage_trackernotexist();
    String msb_changeFromManageToStaff();
    String msb_insertManage_error();
    String msb_removemanages();
    String btnApply();
    String msb_removestaffs();
    String window_title();
    String ccStaff();
    String btnInsertManage();
    String msb_insertStaff_error();
}