package com.bkitmobile.poma.localization.client;

public interface ImageChooserConstants extends com.google.gwt.i18n.client.Constants {
    String btnCancel_text();
    String btnOK_text();
    String arrFieldSetNames_Place();
    String arrFieldSetNames_Star();
    String arrFieldSetNames_Dot();
    String arrFieldSetNames_Transport();
    String tbBtnFind();
    String arrFieldSetNames_Other();
    String arrFieldSetNames_ABC();
    String views_setEmptyText();
}