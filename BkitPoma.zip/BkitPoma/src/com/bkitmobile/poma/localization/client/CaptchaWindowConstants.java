package com.bkitmobile.poma.localization.client;

public interface CaptchaWindowConstants extends com.google.gwt.i18n.client.Constants {
    String captchaError();
    String captchaMessage();
    String captchaFailure();
    String captchaButton();
}