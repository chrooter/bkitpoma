package com.bkitmobile.poma.localization.client;

public interface ContactWindowConstants extends com.google.gwt.i18n.client.Constants {
    String cantSend();
    String windowTitle();
    String notEmpty();
    String send();
    String content();
    String canSend();
    String email();
    String sendMailFailure();
    String title();
    String cancel();
};