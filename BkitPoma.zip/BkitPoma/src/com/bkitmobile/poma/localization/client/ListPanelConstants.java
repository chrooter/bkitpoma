package com.bkitmobile.poma.localization.client;

public interface ListPanelConstants extends com.google.gwt.i18n.client.Constants {
    String firstPageText();
    String nextText();
    String previousText();
    String refreshText();
    String lastPageText();
    String beforePageText();
    String afterPageText();
}