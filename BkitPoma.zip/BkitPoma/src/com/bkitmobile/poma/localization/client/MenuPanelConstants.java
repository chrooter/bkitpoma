package com.bkitmobile.poma.localization.client;

public interface MenuPanelConstants extends com.google.gwt.i18n.client.Constants {
    String disableFail();
    String trackedName();
    String disableTrackedLoadingMsg();
    String newTracked();
    String btnDisableTracked();
    String trackedListNull();
    String settingTab();
    String disableSuccess();
    String trackedPanel_title();
    String tableTracked_col1();
    String tableTracked_col2();
    String tableTracked_title();
};