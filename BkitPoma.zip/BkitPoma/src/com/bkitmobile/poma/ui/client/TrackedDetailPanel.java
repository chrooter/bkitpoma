package com.bkitmobile.poma.ui.client;

import java.util.ArrayList;
import java.util.Date;

import com.bkitmobile.poma.database.client.DatabaseService;
import com.bkitmobile.poma.database.client.DatabaseServiceAsync;
import com.bkitmobile.poma.database.client.ServiceResult;
import com.bkitmobile.poma.database.client.entity.CTrack;
import com.bkitmobile.poma.database.client.entity.CTracked;
import com.bkitmobile.poma.home.client.BkitPoma;
import com.bkitmobile.poma.home.client.UserSettings;
import com.bkitmobile.poma.localization.client.TrackedPanelConstants;
import com.bkitmobile.poma.util.client.OneTimeTask;
import com.bkitmobile.poma.util.client.Task;
import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.gwtext.client.core.EventObject;
import com.gwtext.client.data.ArrayReader;
import com.gwtext.client.data.FieldDef;
import com.gwtext.client.data.MemoryProxy;
import com.gwtext.client.data.Record;
import com.gwtext.client.data.RecordDef;
import com.gwtext.client.data.Store;
import com.gwtext.client.data.StringFieldDef;
import com.gwtext.client.widgets.BoxComponent;
import com.gwtext.client.widgets.Button;
import com.gwtext.client.widgets.Component;
import com.gwtext.client.widgets.DatePicker;
import com.gwtext.client.widgets.MessageBox;
import com.gwtext.client.widgets.Panel;
import com.gwtext.client.widgets.Toolbar;
import com.gwtext.client.widgets.ToolbarButton;
import com.gwtext.client.widgets.event.ButtonListenerAdapter;
import com.gwtext.client.widgets.event.DatePickerListenerAdapter;
import com.gwtext.client.widgets.event.PanelListener;
import com.gwtext.client.widgets.event.PanelListenerAdapter;
import com.gwtext.client.widgets.form.ComboBox;
import com.gwtext.client.widgets.form.DateField;
import com.gwtext.client.widgets.form.Field;
import com.gwtext.client.widgets.form.FormPanel;
import com.gwtext.client.widgets.form.Label;
import com.gwtext.client.widgets.form.ValidationException;
import com.gwtext.client.widgets.form.Validator;
import com.gwtext.client.widgets.form.event.ComboBoxListenerAdapter;
import com.gwtext.client.widgets.form.event.FieldListenerAdapter;
import com.gwtext.client.widgets.grid.GridPanel;
import com.gwtext.client.widgets.grid.RowSelectionModel;
import com.gwtext.client.widgets.grid.event.GridRowListenerAdapter;
import com.gwtext.client.widgets.layout.FitLayout;
import com.gwtext.client.widgets.layout.HorizontalLayout;
import com.gwtext.client.widgets.layout.VerticalLayout;

/**
 * This is Panel in MenuPanel, include: combobox for tracked, tablepanel for
 * track, tablepanel for waypoint
 */
public class TrackedDetailPanel extends Panel {

	private static TrackedDetailPanel trackedDetailPanel;
	public static boolean isUpdateDone = true;

	private static TablePanel trackTable;
	private WayPointPanel waypointTable;

	private FormPanel datePanel;

	private DateField dateFrom;
	private DateField dateTo;

	private TrackedPanelConstants constants = GWT
			.create(TrackedPanelConstants.class);

	DatabaseServiceAsync dbAsync = DatabaseService.Util.getInstance();

	private int heightTrackList = 270;
	private int pageSizeTrack = 5;

	private final int rowGridHeight = 20;
	private final int waypointHeaderHeight = 52;

	public static final int LABEL_WIDTH = 100;
	public static final int COMBOBOX_WIDTH = MenuPanel.WIDTH - LABEL_WIDTH;
	public static final int FIELD_WIDTH = COMBOBOX_WIDTH - 50;
	private int idWidth = 60;

	private boolean filter = false;
	private Store store = null;

	private ComboBox cbTrackedList;

	private Object[][] data;

	private ArrayList<CTrack> trackList;
	private long currentTrackedID = 0;

	/**
	 * Format date in Track table panel
	 */
	private DateTimeFormat dateFormat = DateTimeFormat.getFormat(constants
			.datetimeformat());
	private Toolbar toolbar;

	/**
	 * Default constructor
	 */
	public TrackedDetailPanel() {
		trackedDetailPanel = this;
		init();
		addListener();
		layout();
	}

	/**
	 * Initial form
	 */
	private void init() {
		// init combobox
		data = new Object[][] { { "", "" } };
		MemoryProxy proxy = new PagingMemoryProxy(data);

		RecordDef recordDef = new RecordDef(new FieldDef[] {
				new StringFieldDef("trackedusername"),
				new StringFieldDef("trackedname") });

		ArrayReader reader = new ArrayReader(recordDef);
		store = new Store(proxy, reader);
		cbTrackedList = new ComboBox();
		cbTrackedList.setMinChars(1);
		cbTrackedList.setFieldLabel(constants.cbTrackedList_title());
		cbTrackedList.setDisplayField("trackedname");
		cbTrackedList.setMode(ComboBox.REMOTE);
		cbTrackedList.setTriggerAction(ComboBox.ALL);
		// cbTrackedList.setForceSelection(true);
		cbTrackedList.setLoadingText(constants.cbTrackedList_loadingtext());
		cbTrackedList.setTypeAhead(true);
		cbTrackedList.setSelectOnFocus(true);
		cbTrackedList.setWidth(COMBOBOX_WIDTH);
		cbTrackedList.setPageSize(4);
		cbTrackedList.setValueField("trackedusername");

		store.load();
		cbTrackedList.setStore(store);
		cbTrackedList.addListener(new ComboBoxListenerAdapter() {
			@Override
			public void onSelect(ComboBox comboBox, Record record, int index) {
				MapPanel.clearOverlays();
				loadTrackList(Long.parseLong(record
						.getAsString("trackedusername")));
				if (filter)
					filterTracked();
			}
		});

		toolbar = new Toolbar();
		toolbar.addButton(new ToolbarButton(constants.lbl_device_list(),
				new ButtonListenerAdapter() {
					@Override
					public void onClick(Button button, EventObject e) {
						MenuPanel.getInstance().trackedPage();
					}
				}));

		toolbar.addField(cbTrackedList);

		// Date filter
		dateFrom = new DateField(constants.dateFirst_title(), "d-m-Y");
		dateFrom.setWidth(FIELD_WIDTH);
		dateFrom.setReadOnly(true);
		dateFrom.setMaxValue(new Date());
		dateFrom.setEmptyText(constants.fromDateEmptyText());

		dateFrom.addListener(new DatePickerListenerAdapter() {
			@Override
			public void onSelect(DatePicker dataPicker, Date date) {
				if (dateTo.getValue() != null
						&& dateFrom.getValue().compareTo(dateTo.getValue()) > 0) {
					filter = false;
					dateFrom.markInvalid("Invalid date");
					return;
				}
				if (dateFrom.getValue() != null
						&& dateFrom.getValue().compareTo(dateTo.getValue()) <= 0) {
					filter = true;
					filterTracked();
				}
			}
		});

		// Last date
		dateTo = new DateField(constants.dateLast_title(), "d-m-Y");
		dateTo.setWidth(FIELD_WIDTH);
		dateTo.setEmptyText(constants.toDateEmptyText());
		dateTo.setMaxValue(new Date());
		dateTo.setReadOnly(true);

		dateTo.setValidator(new Validator() {
			@Override
			public boolean validate(String value) throws ValidationException {
				if (dateTo.getValue() != null
						&& dateTo.getValue().compareTo(dateFrom.getValue()) < 0) {
					dateTo.markInvalid("Error");
					return false;
				}
				return true;
			}
		});

		dateTo.addListener(new FieldListenerAdapter() {
			@Override
			public void onValid(Field field) {
				if (dateFrom.getValue() != null
						&& dateFrom.getValue().compareTo(dateTo.getValue()) > 0) {
					filter = false;
					return;
				}
				filter = true;
				filterTracked();
			}
		});

		// Track list
		trackTable = new TablePanel(new int[] { TablePanel.FIELD_STRING,
				TablePanel.FIELD_STRING, TablePanel.FIELD_STRING },
				new String[] { constants.trackNameGrid(),
						constants.trackStartDate(), constants.trackEndDate() });
		trackTable.setLayout(new FitLayout());
		trackTable.getGridPanel()
				.setSelectionModel(new RowSelectionModel(true));
		// trackTable.setHeight(heightTrackList);
		// trackTable.setPageSize(pageSizeTrack);

		int sizes[] = { idWidth, (MenuPanel.WIDTH - idWidth) / 2,
				(MenuPanel.WIDTH - idWidth) / 2 };
		try {
			trackTable.setColumnWidthManually(sizes, true);
		} catch (Exception e) {
			e.printStackTrace();
		}

		waypointTable = new WayPointPanel();
		waypointTable.setLayout(new FitLayout());
		waypointTable.setAutoHeight(true);
		waypointTable.setPageSize(200 / rowGridHeight);
		try {
			waypointTable.setColumnWidthManually(new int[] { MenuPanel.WIDTH },
					false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void addListener() {

		trackTable.addGridRowListener(new GridRowListenerAdapter() {
			@Override
			public void onRowClick(GridPanel grid, int rowIndex, EventObject e) {
				MapPanel.getInstance().startLoading("Loading ...");
				String trackId = trackTable.getRecord(rowIndex).get(0);
				waypointTable.loadWayPointsByTrack(trackId);
			}
		});

		this.addListener(new PanelListenerAdapter() {
			@Override
			public void onResize(BoxComponent component, int adjWidth,
					int adjHeight, int rawWidth, int rawHeight) {
				trackTable
						.setGridHeight(MenuPanel.getInstance().getHeight() - 320);
				trackTable
						.setPageSize((MenuPanel.getInstance().getHeight() - 320)
								/ rowGridHeight);
				BkitPoma.resize();
			}
		});

		UserSettings.timerTask.addTask(new OneTimeTask(1) {
			@Override
			public void executeOne() {
				MenuPanel.getInstance().trackedPage();
			}
		});
	}

	private void layout() {
		this.setLayout(new VerticalLayout(5));

		datePanel = new FormPanel();
		datePanel.setLabelWidth(LABEL_WIDTH);
		datePanel.add(dateFrom);
		datePanel.add(dateTo);

		this.setTopToolbar(toolbar);
		this.add(datePanel);
		this.add(trackTable);
		this.add(waypointTable);
	}

	/**
	 * Use when user wants to view tracked list Auto run when a tracker login,
	 * after load bring into cbTrackedList
	 * 
	 * @param trackerUsername
	 */
	public void loadTrackedList() {
		ArrayList<CTracked> trackedList = new ArrayList<CTracked>(
				UserSettings.ctrackedList.values());
		if (trackedList == null || trackedList.size() == 0)
			return;

		String[][] data = new String[trackedList.size()][];
		for (int i = 0; i < trackedList.size(); i++) {
			String name;
			if (trackedList.get(i).getName().equals("")) {
				name = String.valueOf(trackedList.get(i).getUsername());
			} else {
				name = trackedList.get(i).getName() + " ("
						+ String.valueOf(trackedList.get(i).getUsername())
						+ ")";
			}
			data[i] = new String[] {
					String.valueOf(trackedList.get(i).getUsername()), name };
		}

		store.setDataProxy(new PagingMemoryProxy(data));
		store.load();
		String name = trackedList.get(0).getName().equals("") ? String
				.valueOf(trackedList.get(0).getUsername()) : trackedList.get(0)
				.getName();
		cbTrackedList.setValue(name);

		if (filter)
			filterTracked();
	}

	/**
	 * Call to Database to get all Track by Tracked
	 * 
	 * @param trackedID
	 *            TrackedID when tracker click in the tracked table panel
	 */
	private void loadTrackList(final Long trackedID) {
		if (UserSettings.ctrackedList.containsKey(trackedID)) {
			CTracked tracked = UserSettings.ctrackedList.get(trackedID);

			waypointTable.setTracked(tracked);
			currentTrackedID = trackedID;

			trackTable.startLoading("Loading ...");
			dbAsync.getTracksByTracked(trackedID,
					new AsyncCallback<ServiceResult<ArrayList<CTrack>>>() {

						@Override
						public void onFailure(Throwable caught) {
							caught.printStackTrace();
							trackTable.stopLoading();
						}

						@Override
						public void onSuccess(
								ServiceResult<ArrayList<CTrack>> result) {
							if (result.isOK()) {
								trackTable.removeAllRecords();
								trackList = result.getResult();
								if (trackList == null || trackList.size() == 0) {
									trackTable.stopLoading();
									return;
								}

								for (int i = 0; i < trackList.size(); ++i) {
									if (i == 0) {
										currentTrackedID = trackList.get(0)
												.getTrackedID();
									}
									String dateStart = trackList.get(i)
											.getBeginTime() == null ? ""
											: dateFormat.format(trackList
													.get(i).getBeginTime());
									String dateEnd = trackList.get(i)
											.getEndTime() == null ? ""
											: dateFormat.format(trackList
													.get(i).getEndTime());

									trackTable.addRecord(new String[] {
											trackList.get(i).getTrackID()
													.toString(), dateStart,
											dateEnd });
								}
							} else {
								MessageBox.alert(result.getMessage());
							}

							if (filter)
								filterTracked();
							trackTable.stopLoading();

						}
					});
		}
	}

	/**
	 * When user click dateField, this function will be called to filter track
	 * between start date and end date
	 */
	private void filterTracked() {
		System.out.println("Filter tracked");

		String[][] data = null;
		ArrayList<CTrack> tmp = new ArrayList<CTrack>();
		for (int i = 0; i < trackList.size(); ++i) {
			CTrack cTrack = trackList.get(i);
			if (cTrack.getBeginTime() == null
					|| (cTrack.getBeginTime().compareTo(dateFrom.getValue()) >= 0 && cTrack
							.getBeginTime().compareTo(dateTo.getValue()) <= 0)) {
				tmp.add(cTrack);
			}

		}

		data = new String[tmp.size()][];
		for (int i = 0; i < tmp.size(); i++) {
			String dateStart = tmp.get(i).getBeginTime() == null ? ""
					: dateFormat.format(tmp.get(i).getBeginTime());
			String dateEnd = tmp.get(i).getEndTime() == null ? "" : dateFormat
					.format(tmp.get(i).getEndTime());
			data[i] = new String[] { tmp.get(i).getTrackID().toString(),
					dateStart, dateEnd };
		}
		trackTable.setData(data);
	}

	/**
	 * Timer call to update track
	 */
	public void updateTrackList() {
		if (currentTrackedID != 0) {

			DatabaseService.Util.getInstance().getTracksByTracked(
					currentTrackedID,
					new Date(UserSettings.lastTrackUpdateTime),
					new AsyncCallback<ServiceResult<ArrayList<CTrack>>>() {

						@Override
						public void onFailure(Throwable caught) {
							caught.printStackTrace();
						}

						@Override
						public void onSuccess(
								ServiceResult<ArrayList<CTrack>> result) {

							ArrayList<CTrack> trackList = result.getResult();

							if (trackList != null) {
								for (CTrack ctrack : trackList) {
									String dateStart = ctrack.getBeginTime() == null ? ""
											: dateFormat.format(ctrack
													.getBeginTime());
									String dateEnd = ctrack.getEndTime() == null ? ""
											: dateFormat.format(ctrack
													.getEndTime());
									trackTable.addRecord(new String[] {
											ctrack.getTrackID() + "",
											dateStart, dateEnd }, 0);
								}
							}
						}
					});
		}
	}

	/**
	 * @return Instance of trackedPanel
	 */
	public static TrackedDetailPanel getInstance() {
		return trackedDetailPanel == null ? new TrackedDetailPanel()
				: trackedDetailPanel;
	}

	/**
	 * Show detail of a tracked
	 * 
	 * @param trackedID
	 */
	public void showDetail(Long trackedID) {
		if (trackTable.getRecordsCount() != UserSettings.ctrackedList.size()) {
			loadTrackedList();
		}

		Record[] records = cbTrackedList.getStore().getRecords();
		waypointTable.removeAllRecords();
		waypointTable.setCurrentTrackID("");

		for (Record record : records) {
			if (record.getAsString("trackedusername").equals("" + trackedID)) {
				cbTrackedList.setValue(record.getAsString("trackedname"));
				loadTrackList(Long.parseLong(record
						.getAsString("trackedusername")));
				break;
			}
		}
	}
}
