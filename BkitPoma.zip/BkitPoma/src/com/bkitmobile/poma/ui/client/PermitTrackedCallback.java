package com.bkitmobile.poma.ui.client;

import java.util.ArrayList;

public interface PermitTrackedCallback {
	public void onApplyOperation(ArrayList<String> arrListStaff,ArrayList<String> arrListManage);
}
