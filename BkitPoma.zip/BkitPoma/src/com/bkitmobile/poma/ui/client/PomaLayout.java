package com.bkitmobile.poma.ui.client;

import com.bkitmobile.poma.localization.client.BkitPomaConstants;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Cookies;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.HTML;
import com.gwtext.client.core.EventObject;
import com.gwtext.client.core.RegionPosition;
import com.gwtext.client.widgets.Button;
import com.gwtext.client.widgets.Panel;
import com.gwtext.client.widgets.ToolTip;
import com.gwtext.client.widgets.Toolbar;
import com.gwtext.client.widgets.ToolbarButton;
import com.gwtext.client.widgets.event.ButtonListenerAdapter;
import com.gwtext.client.widgets.layout.BorderLayout;
import com.gwtext.client.widgets.layout.BorderLayoutData;
import com.gwtext.client.widgets.layout.CardLayout;

public class PomaLayout extends LoadingPanel {

	protected static String VI_ICON = "/images/flags/vn.ico";
	protected static String EN_ICON = "/images/flags/en.ico";
	protected static String POMA_LOGO = "/images/poma/logo-header.gif";

	protected Toolbar toolbar;
	private Panel centerPanel;
	private Panel rightPanel;

	private ToolbarButton btnVie;
	private ToolbarButton btnEng;

	private static BkitPomaConstants constants = GWT
			.create(BkitPomaConstants.class);

	private int toolbarHeight = 36;

	public PomaLayout() {
		init();
		HTML logo = new HTML("<img src='images/poma/logo-header.gif' />");
		toolbar.addElement(logo.getElement());
		toolbar.addElement(new HTML(
				"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;")
				.getElement());
		addListener();
	}

	protected void init() {
		this.setLayout(new BorderLayout());

		centerPanel = new Panel();
		centerPanel.setLayout(new CardLayout());

		toolbar = new Toolbar();
		toolbar.setHeight(toolbarHeight);

		// rightPanel = new Panel();
		// rightPanel.setLayout(new CardLayout());

		btnVie = new ToolbarButton();
		btnVie.setIcon("/images/flags/vn.ico");
		ToolTip vieTip = new ToolTip(constants.vieTip());
		vieTip.applyTo(btnVie);

		btnEng = new ToolbarButton();
		ToolTip enTip = new ToolTip(constants.enTip());
		enTip.applyTo(btnEng);
		btnEng.setIcon(EN_ICON);
	}

	protected void layout() {
		add(centerPanel, new BorderLayoutData(RegionPosition.CENTER));
		add(rightPanel, new BorderLayoutData(RegionPosition.EAST));

		toolbar.addFill();
		toolbar.addButton(btnVie);
		toolbar.addButton(btnEng);

		add(toolbar, new BorderLayoutData(RegionPosition.NORTH));
	}

	protected void addListener() {
		btnEng.addListener(new ButtonListenerAdapter() {

			@Override
			public void onClick(Button button, EventObject e) {
				if (Cookies.getCookie("tracker_language") != null
						&& Cookies.getCookie("tracker_language").equals("en"))
					return;
				Cookies.setCookie("tracker_language", "en");
				reloadPage();
			}
		});
		btnVie.addListener(new ButtonListenerAdapter() {
			@Override
			public void onClick(Button button, EventObject e) {
				if (Cookies.getCookie("tracker_language") != null
						&& Cookies.getCookie("tracker_language").equals("vi"))
					return;
				Cookies.setCookie("tracker_language", "vi");
				reloadPage();
			}
		});

	}

	protected void addToCenterPanel(Panel panel) {
		if (centerPanel == null) {
			return;
		}
		centerPanel.add(panel);
	}

	protected void addToCenterPanel(Panel panel, BorderLayoutData data) {
		if (centerPanel == null) {
			return;
		}
		centerPanel.add(panel, data);
	}

	protected void setRightPanel(Panel panel) {
		rightPanel = panel;
		this.add(rightPanel, new BorderLayoutData(RegionPosition.EAST));
	}

	protected void setCenterActivePanel(Panel panel) {
		centerPanel.setActiveItemID(panel.getId());
		if (rightPanel != null) {
			rightPanel.hide();
		}
		panel.setSize(Window.getClientWidth(), Window.getClientHeight());
		fireEvent("resize");
	}

	// protected void setRightActivePanel(String id) {
	// rightPanel.setActiveItemID(id);
	// }

	public void reloadPage() {
		startLoading(constants.loadingMessage());
		_reloadPage();
	}

	private static native void _reloadPage() /*-{
		$wnd.location.reload();
	}-*/;
}
