package com.bkitmobile.poma.ui.client;

import com.bkitmobile.poma.ui.client.MapToolbar.TrackedViewMode;
import com.gwtext.client.widgets.Panel;
import com.gwtext.client.widgets.layout.CardLayout;

/**
 * @author hieu.hua
 */
public class MenuPanel extends LoadingPanel {
	private TrackedDetailPanel trackedDetailPanel;
	private TrackedPanel trackedPanel;

	private static MenuPanel menuPanel;

	public static MenuPanel getInstance() {
		return menuPanel == null ? new MenuPanel() : menuPanel;
	}

	public static final int WIDTH = 310;
	public static final int LABEL_HEIGHT = 20;

	private MenuPanel() {
		super();
		menuPanel = this;
		init();
		layout();
	}

	private void init() {
		trackedDetailPanel = TrackedDetailPanel.getInstance();
		trackedPanel = TrackedPanel.getInstance();
	}

	private void layout() {
		this.setWidth(WIDTH);
		this.setTitle("Menu");
		this.setCollapsible(true);
		this.setLayout(new CardLayout());
		this.add(trackedPanel);
		this.add(trackedDetailPanel);
		this.setActiveItemID(trackedDetailPanel.getId());
	}

	public void detailPage() {
		this.setActiveItemID(trackedDetailPanel.getId());
		TrackedDetailPanel.getInstance().showDetail(
				TrackedPanel.getCurrentTrackedID());
		MapPanel.getInstance().getToolbar().setTrackedViewMode(
				TrackedViewMode.TRACK);
	}

	public void trackedPage() {
		this.setActiveItemID(trackedPanel.getId());
		MapPanel.getInstance().stopLoading();
		WayPointPanel.getInstance().stopLoading();
		MapPanel.getInstance().getToolbar().setTrackedViewMode(
				TrackedViewMode.MULTI_TRACK);
		trackedPanel.addTrackedsToMap();
	}
}
