package com.bkitmobile.poma.ui.client;

import java.util.ArrayList;

import com.bkitmobile.poma.database.client.*;
import com.bkitmobile.poma.database.client.entity.*;
import com.bkitmobile.poma.home.client.UserSettings;
import com.bkitmobile.poma.localization.client.MapPanelConstants;
import com.bkitmobile.poma.util.client.Task;
import com.bkitmobile.poma.ui.client.MapToolbar.TrackedViewMode;
import com.bkitmobile.poma.ui.client.map.*;
import com.google.gwt.core.client.GWT;
import com.google.gwt.maps.client.MapType;
import com.google.gwt.maps.client.MapWidget;
import com.google.gwt.maps.client.control.ControlAnchor;
import com.google.gwt.maps.client.control.ControlPosition;
import com.google.gwt.maps.client.control.LargeMapControl3D;
import com.google.gwt.maps.client.control.Control.CustomControl;
import com.google.gwt.maps.client.event.MapAddOverlayHandler;
import com.google.gwt.maps.client.event.MapClearOverlaysHandler;
import com.google.gwt.maps.client.event.MapClickHandler;
import com.google.gwt.maps.client.event.MapDragStartHandler;
import com.google.gwt.maps.client.event.MapInfoWindowOpenHandler;
import com.google.gwt.maps.client.event.MapMoveEndHandler;
import com.google.gwt.maps.client.event.MapRemoveOverlayHandler;
import com.google.gwt.maps.client.event.MapRightClickHandler;
import com.google.gwt.maps.client.geom.LatLng;
import com.google.gwt.maps.client.geom.LatLngBounds;
import com.google.gwt.maps.client.overlay.Overlay;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Grid;
import com.google.gwt.user.client.ui.Widget;
import com.gwtext.client.core.EventObject;
import com.gwtext.client.core.RegionPosition;
import com.gwtext.client.widgets.BoxComponent;
import com.gwtext.client.widgets.Button;
import com.gwtext.client.widgets.Panel;
import com.gwtext.client.widgets.ToolbarButton;
import com.gwtext.client.widgets.event.ButtonListenerAdapter;
import com.gwtext.client.widgets.event.PanelListenerAdapter;
import com.gwtext.client.widgets.layout.BorderLayout;
import com.gwtext.client.widgets.layout.BorderLayoutData;
import com.gwtext.client.widgets.menu.BaseItem;
import com.gwtext.client.widgets.menu.CheckItem;
import com.gwtext.client.widgets.menu.Item;
import com.gwtext.client.widgets.menu.Menu;
import com.gwtext.client.widgets.menu.event.BaseItemListenerAdapter;
import com.gwtext.client.widgets.menu.event.MenuListenerAdapter;

public class MapPanel extends LoadingPanel {

	private static MapWidget mapWidget;
	private static MapPanel mapPanel;
	private LatLng center;
	private MapToolbar toolbar;
	private Panel panel;
	private Menu popupMenu;
	private PMMapTypeControl customControl;

	private static ArrayList<WayPointOverlay> waypointList = new ArrayList<WayPointOverlay>();

	public static MapWidget getMapWidgetInstance() {
		if (mapWidget == null)
			mapWidget = new MapWidget();
		return mapWidget;
	}

	public MapPanel() {
		constructor();
	}

	public MapPanel(String title) {
		super(title);
		constructor();
	}

	public void constructor() {
		setLayout(new BorderLayout());
		popupMenu = new Menu();
		popupMenu.addItem(new Item("one"));
		popupMenu.addItem(new Item("two"));
		popupMenu.addListener(new MenuListenerAdapter() {
			@Override
			public void onItemClick(BaseItem item, EventObject e) {

			}
		});

		panel = new Panel();
		mapWidget = getMapWidgetInstance();

		// mapWidget.addMapRightClickHandler(new MapRightClickHandler() {
		//
		// @Override
		// public void onRightClick(MapRightClickEvent event) {
		// // int x = event.getPoint().getX() + Window.getScrollLeft();
		// // int y = event.getPoint().getY() + Window.getScrollTop();
		// int x = event.getPoint().getX();
		// int y = event.getPoint().getY() + mapWidget.getAbsoluteTop();
		// popupMenu.showAt(x, y);
		// }
		//
		// });

		mapWidget.addInfoWindowOpenHandler(new MapInfoWindowOpenHandler() {

			@Override
			public void onInfoWindowOpen(MapInfoWindowOpenEvent event) {
				mapWidget.setCenter(center);
			}
		});

		mapWidget.addMapMoveEndHandler(new MapMoveEndHandler() {

			@Override
			public void onMoveEnd(MapMoveEndEvent event) {
				center = mapWidget.getCenter();
			}
		});

		mapWidget.addMapClickHandler(new MapClickHandler() {

			@Override
			public void onClick(MapClickEvent event) {
				popupMenu.hide();
			}

		});

		mapWidget.addMapDragStartHandler(new MapDragStartHandler() {
			@Override
			public void onDragStart(MapDragStartEvent event) {
				popupMenu.hide();
			}
		});

		mapWidget.addMapAddOverlayHandler(new MapAddOverlayHandler() {

			@Override
			public void onAddOverlay(MapAddOverlayEvent event) {
				Overlay overlay = event.getOverlay();
				if (overlay instanceof WayPointOverlay) {
					WayPointOverlay point = (WayPointOverlay) overlay;

					waypointList.add(point);
				}
			}
		});

		mapWidget.addMapClearOverlaysHandler(new MapClearOverlaysHandler() {

			@Override
			public void onClearOverlays(MapClearOverlaysEvent event) {
				waypointList.clear();
			}
		});

		mapWidget.addMapRemoveOverlayHandler(new MapRemoveOverlayHandler() {

			@Override
			public void onRemoveOverlay(MapRemoveOverlayEvent event) {
				Overlay overlay = event.getOverlay();
				if (overlay instanceof WayPointOverlay) {
					WayPointOverlay point = (WayPointOverlay) overlay;
					waypointList.remove(point);
				}
			}
		});

		panel.add(mapWidget);
		mapWidget.setSize("100%", "100%");

		// mapWidget.setUIToDefault();
		mapWidget.setScrollWheelZoomEnabled(true);

		add(panel, new BorderLayoutData(RegionPosition.CENTER));

		setCenter(10.760065, 106.662469);
		setZoomLevel(17);

		panel.addListener(new PanelListenerAdapter() {
			@Override
			public void onResize(BoxComponent component, int adjWidth,
					int adjHeight, int rawWidth, int rawHeight) {

				mapWidget.checkResizeAndCenter();
			}
		});

		toolbar = new MapToolbar();

		customControl = new PMMapTypeControl();
		mapWidget.addControl(customControl);
		mapWidget.addControl(new LargeMapControl3D());
		mapPanel = this;
	}

	public static void setMaxLatLngBound() {
		LatLngBounds bound = LatLngBounds.newInstance();

		for (WayPointOverlay point : waypointList) {
			bound.extend(point.getLatLng());
		}

		int zoomLevel = mapWidget.getBoundsZoomLevel(bound);
		zoomLevel = zoomLevel < mapWidget.getCurrentMapType()
				.getMinimumResolution() ? mapWidget.getCurrentMapType()
				.getMinimumResolution() : zoomLevel;
		mapWidget.setZoomLevel(zoomLevel);
		mapWidget.panTo(bound.getCenter());
	}

	public void boundToTracked(Long currentTrackedID) {
		if (!UserSettings.currentTrackOverlay.containsKey(currentTrackedID)) {
			return;
		}
		LatLngBounds bound = LatLngBounds.newInstance();
		TrackPointOverlay trackOverlay = UserSettings.currentTrackOverlay
				.get(currentTrackedID);
		for (WayPointOverlay overlay : trackOverlay.getWayPointOverlays()) {
			bound.extend(overlay.getLatLng());
		}

		MapWidget widget = MapPanel.getMapWidgetInstance();
		int zoomLevel = widget.getBoundsZoomLevel(bound);
		zoomLevel = zoomLevel < widget.getCurrentMapType()
				.getMinimumResolution() ? widget.getCurrentMapType()
				.getMinimumResolution() : zoomLevel;

		widget.setZoomLevel(zoomLevel);

		widget.setCenter(bound.getCenter());
	}

	public void setMaxIcon() {
		// if (UserSettings.MAP_MAXIMIZED)
	}

	public ToolbarButton getMaxButton() {
		return toolbar.maxButton;
	}

	public void init() {
		mapWidget.checkResizeAndCenter();
	}

	public void setCenter(double lat, double lng) {
		center = LatLng.newInstance(lat, lng);
		mapWidget.panTo(center);
	}

	public void setCenter(LatLng center) {
		this.center = center;
		mapWidget.setCenter(center);
	}

	public void panTo(LatLng center) {
		this.center = center;
		mapWidget.panTo(center);
	}

	public void setZoomLevel(int level) {
		mapWidget.setZoomLevel(level);
	}

	public void addOverlay(Overlay overlay) {
		if (overlay != null) {
			mapWidget.addOverlay(overlay);
		}
	}

	public void removeOverlay(Overlay overlay) {
		if (overlay != null) {
			mapWidget.removeOverlay(overlay);
		}
	}

	public void setMapWidget(MapWidget map) {
		mapWidget = map;
	}

	public static MapPanel getInstance() {
		return mapPanel;
	}

	public void setToolbarVisible() {

		Task countDownTask = toolbar.getCountDownTask();

		if (!UserSettings.timerTask.getTaskList().contains(countDownTask)) {
			setTopToolbar(toolbar);
			UserSettings.timerTask.getTaskList().add(countDownTask);
			customControl.setTraceAllButtonVisible(true);
		}
	}

	public static void clearOverlays() {
		mapWidget.clearOverlays();
		waypointList.clear();
	}

	public void setTrackedViewMode(TrackedViewMode mode) {
		toolbar.setTrackedViewMode(mode);

		clearOverlays();
	}

	public static void addToMap(final CTracked tracked) {
		addToMap(tracked, false, null, null);
	}

	public static void addToMap(final CTracked tracked, final boolean follow,
			final Long curID, final Long preID) {
		if (tracked.getShowInMap() != null && !tracked.getShowInMap()) {
			return;
		}

		if (UserSettings.currentTrackOverlay.containsKey(tracked.getUsername())) {
			TrackPointOverlay trackOverlay = UserSettings.currentTrackOverlay
					.get(tracked.getUsername());
			trackOverlay.addTrackPointOverlayToMap();
			if (follow) {
				setTrackedFollow(curID, preID);
			}
			return;
		}

		DatabaseService.Util.getInstance().getLastestWaypointTracked(
				tracked.getUsername(),
				new AsyncCallback<ServiceResult<CWaypoint>>() {

					@Override
					public void onFailure(Throwable caught) {
						caught.printStackTrace();
					}

					@Override
					public void onSuccess(ServiceResult<CWaypoint> result) {
						CWaypoint point = result.getResult();

						if (point != null) {
							final TrackPointOverlay trackOverlay = new TrackPointOverlay(
									new CWaypoint[] { point }, tracked);

							UserSettings.currentTrackOverlay.put(tracked
									.getUsername(), trackOverlay);
							if (follow) {
								setTrackedFollow(curID, preID);
							}

							trackOverlay.addTrackPointOverlayToMap();
						}
					}
				});
	}

	public MapToolbar getToolbar() {
		return toolbar;
	}

	public static void setTrackedFollow(Long currentTrackedID,
			Long previousTrackedID) {
		if (previousTrackedID != null) {
			System.out.println("Previous : " + previousTrackedID);
			if (UserSettings.currentTrackOverlay.containsKey(previousTrackedID))
				UserSettings.currentTrackOverlay.get(previousTrackedID)
						.setFollowLastWaypointMode(false);
		}

		if (currentTrackedID != null) {
			System.out.println("Currents : " + currentTrackedID);
			if (UserSettings.currentTrackOverlay.containsKey(currentTrackedID))
				UserSettings.currentTrackOverlay.get(currentTrackedID)
						.setFollowLastWaypointMode(true);
		}
	}

	public static void removeFromMap(Long trackedID) {

		if (UserSettings.currentTrackOverlay.containsKey(trackedID)) {

			TrackPointOverlay trackOverlay = UserSettings.currentTrackOverlay
					.remove(trackedID);
			trackOverlay.removeOverlay();
		}
	}
}

class PMMapTypeControl extends CustomControl {

	protected PMMapTypeControl() {
		super(new ControlPosition(ControlAnchor.TOP_RIGHT, 3, 3));
	}

	private static MapPanelConstants constants = GWT
			.create(MapPanelConstants.class);

	private Button traceAllButton;

	@Override
	protected Widget initialize(final MapWidget map) {
		Grid grid = new Grid(1, 2);

		Menu mapTypeMenu = new Menu();

		CheckItem trafficItem = new CheckItem(constants.trafficLabel(), true);
		trafficItem.setGroup("maptype");
		trafficItem.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
				int zoomLevel = map.getZoomLevel();
				zoomLevel = zoomLevel < MapType.getNormalMap()
						.getMinimumResolution() ? MapType.getNormalMap()
						.getMinimumResolution() : zoomLevel;
				map.setCurrentMapType(MapType.getNormalMap());
				map.setZoomLevel(zoomLevel);
			}
		});

		CheckItem satelliteItem = new CheckItem("Satelitte", true);
		satelliteItem.setGroup("maptype");
		satelliteItem.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
				int zoomLevel = map.getZoomLevel();
				zoomLevel = zoomLevel < MapType.getSatelliteMap()
						.getMinimumResolution() ? MapType.getSatelliteMap()
						.getMinimumResolution() : zoomLevel;
				map.setCurrentMapType(MapType.getSatelliteMap());
				map.setZoomLevel(zoomLevel);
			}
		});

		CheckItem hybridItem = new CheckItem(constants.hybridLabel());
		hybridItem.setGroup("maptype");
		hybridItem.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
				int zoomLevel = map.getZoomLevel();
				zoomLevel = zoomLevel < MapType.getHybridMap()
						.getMinimumResolution() ? MapType.getHybridMap()
						.getMinimumResolution() : zoomLevel;
				map.setCurrentMapType(MapType.getHybridMap());
				map.setZoomLevel(zoomLevel);
			}
		});

		CheckItem terrainItem = new CheckItem(constants.terrainLabel());
		terrainItem.setGroup("maptype");
		terrainItem.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
				int zoomLevel = map.getZoomLevel();
				zoomLevel = zoomLevel < MapType.getPhysicalMap()
						.getMinimumResolution() ? MapType.getPhysicalMap()
						.getMinimumResolution() : zoomLevel;
				map.setCurrentMapType(MapType.getPhysicalMap());
				map.setZoomLevel(zoomLevel);
			}
		});

		CheckItem earthItem = new CheckItem(constants.earthLabel());
		earthItem.setGroup("maptype");
		earthItem.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
				map.setCurrentMapType(MapType.getEarthMap());
			}
		});

		mapTypeMenu.addItem(trafficItem);
		mapTypeMenu.addItem(satelliteItem);
		mapTypeMenu.addItem(hybridItem);
		mapTypeMenu.addItem(terrainItem);
		mapTypeMenu.addItem(earthItem);

		Button mapTypeButton = new Button(constants.mapTypeLabel());
		mapTypeButton.setMenu(mapTypeMenu);

		traceAllButton = new Button(constants.traceAllLabel());

		traceAllButton.addListener(new ButtonListenerAdapter() {

			@Override
			public void onClick(Button button, EventObject e) {
				MapPanel.setMaxLatLngBound();
			}

		});

		traceAllButton.setVisible(false);

		grid.setWidget(0, 0, mapTypeButton);
		grid.setWidget(0, 1, traceAllButton);

		return grid;
	}

	@Override
	public boolean isSelectable() {
		return false;
	}

	public void setTraceAllButtonVisible(boolean visible) {
		traceAllButton.setVisible(visible);
	}

}
