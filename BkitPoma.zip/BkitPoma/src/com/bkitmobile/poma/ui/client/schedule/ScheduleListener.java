package com.bkitmobile.poma.ui.client.schedule;

/**
 * Listener 
 * @author Hieu
 *
 */
public interface ScheduleListener {
	public void onChanged(int index, boolean b);
}
