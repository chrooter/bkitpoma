package com.bkitmobile.poma.util.server.kml;

public enum ListItemTypeEnum {
	check, checkOffOnly, checkHideChildren, radioFolder
}
