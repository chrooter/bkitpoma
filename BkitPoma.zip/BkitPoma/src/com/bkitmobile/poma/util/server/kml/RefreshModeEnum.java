package com.bkitmobile.poma.util.server.kml;

public enum RefreshModeEnum {
	onChange, onInterval, onExpire
}
