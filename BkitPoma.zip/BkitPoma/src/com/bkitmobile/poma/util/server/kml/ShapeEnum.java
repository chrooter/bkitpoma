package com.bkitmobile.poma.util.server.kml;

public enum ShapeEnum {
	rectangle, cylinder, sphere
}
