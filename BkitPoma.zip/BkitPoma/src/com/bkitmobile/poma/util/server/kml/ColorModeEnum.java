package com.bkitmobile.poma.util.server.kml;

public enum ColorModeEnum {
	normal, random
}
