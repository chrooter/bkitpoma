package com.bkitmobile.poma.util.server.kml;

public enum SimpleFieldTypeEnum {
	string, _int, uint, _short, ushort, _float, _double, bool
}
