package com.bkitmobile.poma.util.server.kml;

public class KmlException extends Exception {

	private static final long serialVersionUID = 1L;

	public KmlException() {
		super();
	}

	public KmlException(String arg0) {
		super(arg0);
	}

	public KmlException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public KmlException(Throwable arg0) {
		super(arg0);
	}
}
