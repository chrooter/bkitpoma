package com.bkitmobile.poma.util.server.kml;

public enum ViewRefreshModeEnum {
	never, onStop, onRequest, onRegion
}
