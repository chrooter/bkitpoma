package com.bkitmobile.poma.util.server.kml;

public abstract class StyleSelector extends KmlObject {	
}