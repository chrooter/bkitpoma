package com.bkitmobile.poma.util.server.kml;

public enum UnitEnum {
	pixels, fraction, insetPixels
}
