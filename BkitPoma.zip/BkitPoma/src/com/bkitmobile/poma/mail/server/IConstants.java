package com.bkitmobile.poma.mail.server;

public interface IConstants {
	public static String HOST = "http://bkitpoma.appspot.com/";
	public static final int MODE_VERIFYEMAILNEWTRACKER = 0;
	public static final int MODE_GOTNEWPASSWORD = 1;
}
