package org.verisign.joid.consumer;

/**
 * User: treeder
 * Date: Jun 20, 2007
 * Time: 11:23:55 PM
 */
public class AuthenticationException extends RuntimeException {
	public AuthenticationException(String s) {
		super(s);
	}
}
