function newArray() {
	return new Array();
}